# Meja Utama — Aplikasi Android (Capacitor)

APK ini adalah "cangkang" yang membuka aplikasi kasir Anda di hosting
(`app.config.json` → `appUrl`). PHP + database tetap di server, jadi semua
perangkat (kasir, waiter, dapur) memakai data yang sama. Yang ditambahkan APK:

- ikon + splash "Meja Utama", layar penuh, layar tidak mati sendiri
- cetak struk ke **printer thermal Bluetooth** (ESC/POS)
- bunyi notifikasi bisa langsung diputar (layar dapur)
- tombol Unduh CSV berfungsi (masuk folder Download)
- halaman "Tidak ada koneksi" yang rapi + otomatis mencoba lagi

## Isi folder

| Berkas | Fungsi |
|---|---|
| `app.config.json` | alamat aplikasi, nama, ID paket |
| `capacitor.config.js` | pengaturan Capacitor (jarang perlu diubah) |
| `assets/` | sumber ikon & splash (ganti PNG bila mau logo lain) |
| `www-src/` | halaman lokal (offline) |
| `native/java/` | kode native: plugin printer Bluetooth + MainActivity |
| `scripts/` | skrip yang menyiapkan proyek Android otomatis |
| `.github/workflows/build-apk.yml` | pembangun APK di GitHub (tanpa Android Studio) |

## Membangun APK lewat GitHub (bisa dari iPad)

1. Buat repo baru di github.com (pilih **Private**).
2. **Add file → Upload files** → unggah `meja-utama-app.zip` (jangan diekstrak) → Commit.
3. **Add file → Create new file**, ketik nama `.github/workflows/build-apk.yml`,
   tempel isi berkas `build-apk.yml`, lalu Commit.
4. Tab **Actions → Build APK Meja Utama → Run workflow**.
   Isi `app_url` dengan alamat aplikasi Anda (alamat halaman login: `https://satuproyeksi.com/profiles/pointofsales/login.php`) → Run.
5. Tunggu ±6–10 menit sampai hijau. Buka run-nya → bagian **Artifacts** → unduh
   **MejaUtama-APK** → ekstrak → `app-debug.apk`.
6. Kirim APK ke HP/tablet Android (WhatsApp, Drive, kabel), buka, izinkan
   "Instal dari sumber tidak dikenal". Bila Play Protect memperingatkan, pilih
   "Tetap instal" (wajar untuk APK di luar Play Store).

Versi berikutnya: jalankan workflow lagi dengan `version_code` lebih besar
(2, 3, ...) lalu instal di atas aplikasi lama (data login tetap).

## Kapan APK perlu dibangun ulang?

- Perubahan di situs/PHP: **tidak perlu**. APK memuat situs langsung — cukup unggah ke hosting.
- Perlu bangun ulang hanya jika mengganti: alamat situs, nama/ikon, ID paket, atau kode native.

## APK rilis bertanda tangan (opsional, untuk Play Store)

Debug APK sudah cukup untuk dipasang di perangkat sendiri/klien. Untuk Play Store,
buat keystore lalu isi Secrets repo: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
`KEY_ALIAS`, `KEY_PASSWORD`, dan jalankan workflow dengan `release` dicentang.
**Simpan keystore baik-baik** — kalau hilang, aplikasi tidak bisa diperbarui.

## Membangun di komputer (opsional)

Butuh Node 22+, JDK 21, Android SDK.

    npm ci
    npm run setup
    cd android && ./gradlew assembleDebug

APK ada di `android/app/build/outputs/apk/debug/`.

## Memakai printer thermal

1. Nyalakan printer, **pairing** lewat Pengaturan → Bluetooth Android (PIN 0000 / 1234).
2. Di aplikasi: **Pengaturan → Aplikasi Android & Printer Struk → Cari Printer**,
   ketuk printernya, lalu **Cetak Tes**.
3. Pilihan printer tersimpan per perangkat.

Di kode halaman kasir, cetak dengan:

    MejaNative.print(receipt);   // thermal jika ada, kalau tidak window.print()

Bentuk `receipt` ada di komentar `assets/native-bridge.js`.
Ukuran kertas (58/80mm) & urutan bagian struk mengikuti Pengaturan admin.
