// Konfigurasi Capacitor. Alamat aplikasi diambil dari app.config.json
// (atau variabel lingkungan APP_URL saat build di GitHub Actions).
const fs = require('fs');
const path = require('path');

const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'app.config.json'), 'utf8'));
const appUrl = (process.env.APP_URL || cfg.appUrl).trim();
const host = new URL(appUrl).hostname;

/** @type {import('@capacitor/cli').CapacitorConfig} */
const config = {
  appId: cfg.appId,
  appName: cfg.appName,
  webDir: 'www',
  backgroundColor: '#1c1a35',
  server: {
    // Aplikasi memuat situs hosting langsung -> semua perangkat memakai data yang sama.
    url: appUrl,
    androidScheme: 'https',
    cleartext: false,
    // Halaman lokal (www/offline.html) yang tampil kalau server tidak terjangkau.
    errorPath: 'offline.html',
    // Domain yang boleh dibuka DI DALAM aplikasi (selain itu dibuka di browser luar).
    allowNavigation: [host, '*.' + host, '*.midtrans.com', '*.midtrans.io']
  },
  android: {
    allowMixedContent: false,
    // Tanda pengenal untuk server/JS: "MejaUtamaApp/1.0"
    appendUserAgent: 'MejaUtamaApp/1.0',
    webContentsDebuggingEnabled: false
  }
};

module.exports = config;
