package __APP_ID__;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Build;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

/**
 * Plugin cetak struk ke printer thermal Bluetooth klasik (SPP / ESC-POS).
 * Printer harus sudah di-pairing dulu lewat Pengaturan Bluetooth Android
 * (PIN umumnya 0000 atau 1234).
 *
 * JS: Capacitor.Plugins.ThermalPrinter.listPrinters()
 *     Capacitor.Plugins.ThermalPrinter.print({ address, data })  // data = base64 byte ESC/POS
 */
@CapacitorPlugin(
    name = "ThermalPrinter",
    permissions = {
        @Permission(alias = "bluetooth", strings = { Manifest.permission.BLUETOOTH_CONNECT })
    }
)
public class ThermalPrinterPlugin extends Plugin {

    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int CHUNK = 512;

    private boolean needsRuntimePermission() {
        // BLUETOOTH_CONNECT baru ada mulai Android 12 (API 31).
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            && getPermissionState("bluetooth") != PermissionState.GRANTED;
    }

    @PluginMethod
    public void listPrinters(PluginCall call) {
        if (needsRuntimePermission()) {
            requestPermissionForAlias("bluetooth", call, "listPermsCallback");
            return;
        }
        doList(call);
    }

    @PermissionCallback
    private void listPermsCallback(PluginCall call) {
        if (needsRuntimePermission()) {
            call.reject("Izin Bluetooth ditolak. Aktifkan lewat Pengaturan > Aplikasi > Meja Utama > Izin.");
            return;
        }
        doList(call);
    }

    @PluginMethod
    public void print(PluginCall call) {
        if (needsRuntimePermission()) {
            requestPermissionForAlias("bluetooth", call, "printPermsCallback");
            return;
        }
        doPrint(call);
    }

    @PermissionCallback
    private void printPermsCallback(PluginCall call) {
        if (needsRuntimePermission()) {
            call.reject("Izin Bluetooth ditolak. Aktifkan lewat Pengaturan > Aplikasi > Meja Utama > Izin.");
            return;
        }
        doPrint(call);
    }

    private BluetoothAdapter adapter() {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        return bm != null ? bm.getAdapter() : null;
    }

    @SuppressLint("MissingPermission")
    private void doList(PluginCall call) {
        BluetoothAdapter ad = adapter();
        if (ad == null) {
            call.reject("Perangkat ini tidak punya Bluetooth.");
            return;
        }
        if (!ad.isEnabled()) {
            call.reject("Bluetooth sedang mati. Nyalakan dulu lalu coba lagi.");
            return;
        }
        JSArray arr = new JSArray();
        Set<BluetoothDevice> bonded = ad.getBondedDevices();
        if (bonded != null) {
            for (BluetoothDevice d : bonded) {
                JSObject o = new JSObject();
                o.put("name", d.getName() != null ? d.getName() : d.getAddress());
                o.put("address", d.getAddress());
                arr.put(o);
            }
        }
        JSObject res = new JSObject();
        res.put("printers", arr);
        call.resolve(res);
    }

    @SuppressLint("MissingPermission")
    private void doPrint(final PluginCall call) {
        final String address = call.getString("address");
        final String b64 = call.getString("data");
        if (address == null || address.isEmpty()) {
            call.reject("Printer belum dipilih.");
            return;
        }
        if (b64 == null || b64.isEmpty()) {
            call.reject("Data cetak kosong.");
            return;
        }
        final BluetoothAdapter ad = adapter();
        if (ad == null || !ad.isEnabled()) {
            call.reject("Bluetooth sedang mati. Nyalakan dulu lalu coba lagi.");
            return;
        }
        final byte[] bytes;
        try {
            bytes = Base64.decode(b64, Base64.DEFAULT);
        } catch (IllegalArgumentException e) {
            call.reject("Data cetak tidak valid.");
            return;
        }

        // Jalankan di thread latar supaya UI tidak macet.
        getBridge().execute(new Runnable() {
            @Override
            public void run() {
                BluetoothSocket socket = null;
                try {
                    BluetoothDevice device = ad.getRemoteDevice(address);
                    ad.cancelDiscovery();
                    try {
                        socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                        socket.connect();
                    } catch (IOException first) {
                        // Beberapa printer murah hanya mau lewat soket "insecure".
                        try { if (socket != null) socket.close(); } catch (IOException ignore) {}
                        socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                        socket.connect();
                    }
                    OutputStream out = socket.getOutputStream();
                    int off = 0;
                    while (off < bytes.length) {
                        int len = Math.min(CHUNK, bytes.length - off);
                        out.write(bytes, off, len);
                        out.flush();
                        off += len;
                        Thread.sleep(40);
                    }
                    // Beri waktu printer menuntaskan buffer sebelum soket ditutup.
                    Thread.sleep(400);
                    call.resolve();
                } catch (Exception e) {
                    call.reject("Gagal mencetak: " + e.getMessage());
                } finally {
                    try { if (socket != null) socket.close(); } catch (IOException ignore) {}
                }
            }
        });
    }
}
