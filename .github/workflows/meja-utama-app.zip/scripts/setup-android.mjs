// Satu perintah menyiapkan proyek Android: npm run setup
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const run = (cmd) => { console.log('\n$ ' + cmd); execSync(cmd, { stdio: 'inherit', cwd: root }); };

run('node scripts/prepare-www.mjs');
if (!fs.existsSync(path.join(root, 'android'))) run('npx cap add android');
run('node scripts/patch-android.mjs');
run('npx capacitor-assets generate --android --assetPath assets');
run('npx cap sync android');
console.log('\nProyek Android siap. Build: cd android && ./gradlew assembleDebug');
