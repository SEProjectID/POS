// Membuat folder www/ (halaman lokal untuk kondisi offline) dari www-src/.
// Alamat aplikasi disisipkan dari app.config.json atau env APP_URL.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'app.config.json'), 'utf8'));
const appUrl = (process.env.APP_URL || cfg.appUrl).trim();

const src = path.join(root, 'www-src');
const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

for (const f of fs.readdirSync(src)) {
  const from = path.join(src, f);
  const to = path.join(out, f);
  if (/\.(html|js|css)$/.test(f)) {
    fs.writeFileSync(to, fs.readFileSync(from, 'utf8').replaceAll('__APP_URL__', appUrl).replaceAll('__APP_NAME__', cfg.appName));
  } else {
    fs.copyFileSync(from, to);
  }
}
console.log('www/ siap ->', appUrl);
