package __APP_ID__;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.TextUtils;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * Jembatan JS <-> layanan pembaca notifikasi pembayaran.
 *
 * JS: Capacitor.Plugins.PayNotif.configure({ url, token, packages: [..] })
 *     Capacitor.Plugins.PayNotif.status()
 *     Capacitor.Plugins.PayNotif.openSettings()          // izin Akses Notifikasi
 *     Capacitor.Plugins.PayNotif.openBatterySettings()   // bebas hemat baterai
 *     Capacitor.Plugins.PayNotif.recent()                // diagnosa (lokal)
 *     Capacitor.Plugins.PayNotif.testSend({ pkg, text }) // uji baca di server (tidak melunasi)
 *     Capacitor.Plugins.PayNotif.disconnect()
 */
@CapacitorPlugin(name = "PayNotif")
public class PayNotifPlugin extends Plugin {

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PaymentNotificationListener.PREFS, Context.MODE_PRIVATE);
    }

    private boolean listenerEnabled() {
        Context ctx = getContext();
        String flat = Settings.Secure.getString(ctx.getContentResolver(), "enabled_notification_listeners");
        if (TextUtils.isEmpty(flat)) return false;
        ComponentName me = new ComponentName(ctx, PaymentNotificationListener.class);
        for (String s : flat.split(":")) {
            ComponentName cn = ComponentName.unflattenFromString(s);
            if (cn != null && cn.equals(me)) return true;
        }
        return false;
    }

    private boolean batteryIgnored() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
    }

    @PluginMethod
    public void configure(PluginCall call) {
        SharedPreferences.Editor e = prefs().edit();
        String url = call.getString("url");
        String token = call.getString("token");
        if (url != null) e.putString("url", url);
        if (token != null) e.putString("token", token);
        JSArray pk = call.getArray("packages");
        if (pk != null) {
            Set<String> set = new HashSet<>();
            try {
                for (int i = 0; i < pk.length(); i++) {
                    String s = pk.getString(i);
                    if (s != null && !s.trim().isEmpty()) set.add(s.trim());
                }
            } catch (Exception ignored) { }
            e.putStringSet("packages", set);
        }
        e.apply();
        new Thread(() -> PaymentNotificationListener.ping(getContext())).start();
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        SharedPreferences p = prefs();
        JSObject r = new JSObject();
        r.put("listenerEnabled", listenerEnabled());
        r.put("configured", !p.getString("token", "").isEmpty() && !p.getString("url", "").isEmpty());
        JSArray arr = new JSArray();
        Set<String> set = p.getStringSet("packages", new HashSet<>());
        if (set != null) for (String s : set) arr.put(s);
        r.put("packages", arr);
        r.put("batteryIgnored", batteryIgnored());
        r.put("queue", PaymentNotificationListener.queueSize(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Intent i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void openBatterySettings(PluginCall call) {
        Context ctx = getContext();
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception e) {
            Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        }
        call.resolve();
    }

    @PluginMethod
    public void recent(PluginCall call) {
        JSObject r = new JSObject();
        // Catatan: JSArray.from(List) mengembalikan null (hanya menerima array
        // Java), jadi item dimasukkan satu per satu dengan put().
        JSArray items = new JSArray();
        try {
            JSONArray arr = new JSONArray(prefs().getString("recent", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                JSObject j = new JSObject();
                j.put("pkg", o.optString("pkg"));
                j.put("label", o.optString("label"));
                j.put("text", o.optString("text"));
                j.put("time", o.optLong("time"));
                items.put(j);
            }
        } catch (Exception ignored) { }
        r.put("items", items);
        call.resolve(r);
    }

    @PluginMethod
    public void testSend(PluginCall call) {
        final String pkg = call.getString("pkg", "");
        final String text = call.getString("text", "");
        new Thread(() -> {
            JSONObject item = new JSONObject();
            try { item.put("pkg", pkg); item.put("title", ""); item.put("text", text); item.put("key", "test-" + System.currentTimeMillis()); } catch (Exception ignored) { }
            String resp = PaymentNotificationListener.sendRaw(getContext(), item, true);
            if (resp == null) { call.reject("Tidak bisa menghubungi server (cek internet / HP belum terhubung)."); return; }
            JSObject r = new JSObject();
            r.put("response", resp);
            call.resolve(r);
        }).start();
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        prefs().edit().remove("url").remove("token").remove("packages").remove("queue").apply();
        call.resolve();
    }
}
