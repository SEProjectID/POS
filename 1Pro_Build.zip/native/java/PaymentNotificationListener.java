package __APP_ID__;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Membaca notifikasi "uang masuk" dari aplikasi merchant/bank yang DIIZINKAN
 * (daftar paket diatur admin 1Pro), lalu meneruskannya ke server
 * (api_notif.php) supaya pembayaran QRIS statis bisa lunas otomatis.
 *
 * Privasi: notifikasi dari aplikasi lain TIDAK dikirim ke mana pun. Untuk
 * membantu admin menemukan nama paket aplikasi merchant, 25 notifikasi
 * terakhir yang memuat "Rp"/"IDR" disimpan HANYA di HP ini (menu Diagnosa).
 */
public class PaymentNotificationListener extends NotificationListenerService {

    static final String PREFS = "onepro_paynotif";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final int MAX_RECENT = 25;
    private static final int MAX_QUEUE = 50;

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        IO.execute(() -> { ping(this); flushQueue(this); });
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getNotification() == null) return;
            String pkg = sbn.getPackageName();
            if (pkg == null || pkg.equals(getPackageName())) return;
            Bundle ex = sbn.getNotification().extras;
            if (ex == null) return;
            String title = str(ex.getCharSequence(Notification.EXTRA_TITLE));
            CharSequence big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
            String text = big != null ? big.toString() : str(ex.getCharSequence(Notification.EXTRA_TEXT));
            String all = (title + " " + text).toLowerCase(Locale.ROOT);
            if (!(all.contains("rp") || all.contains("idr"))) return;

            final Context ctx = getApplicationContext();
            rememberRecent(ctx, pkg, labelOf(ctx, pkg), title, text, sbn.getPostTime());

            SharedPreferences p = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
            Set<String> allowed = p.getStringSet("packages", new HashSet<>());
            if (allowed == null || !allowed.contains(pkg)) return;
            if (p.getString("token", "").isEmpty() || p.getString("url", "").isEmpty()) return;

            final String key = pkg + ":" + sbn.getPostTime() + ":" + Integer.toHexString((title + "|" + text).hashCode());
            final String fPkg = pkg, fTitle = title, fText = text;
            IO.execute(() -> {
                JSONObject item = new JSONObject();
                try {
                    item.put("pkg", fPkg); item.put("title", fTitle); item.put("text", fText); item.put("key", key);
                } catch (Exception ignored) { }
                if (!send(ctx, item, false)) enqueue(ctx, item);
                flushQueue(ctx);
            });
        } catch (Exception ignored) {
            // Jangan pernah membuat layanan crash karena satu notifikasi aneh.
        }
    }

    // ---------------------------------------------------------------------

    static String str(CharSequence c) { return c == null ? "" : c.toString(); }

    static String labelOf(Context ctx, String pkg) {
        try {
            PackageManager pm = ctx.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return String.valueOf(pm.getApplicationLabel(ai));
        } catch (Exception e) { return pkg; }
    }

    static synchronized void rememberRecent(Context ctx, String pkg, String label, String title, String text, long time) {
        try {
            SharedPreferences p = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray arr = new JSONArray(p.getString("recent", "[]"));
            JSONObject o = new JSONObject();
            String t = (title + " | " + text);
            if (t.length() > 240) t = t.substring(0, 240);
            o.put("pkg", pkg); o.put("label", label); o.put("text", t); o.put("time", time);
            arr.put(o);
            JSONArray trimmed = new JSONArray();
            for (int i = Math.max(0, arr.length() - MAX_RECENT); i < arr.length(); i++) trimmed.put(arr.get(i));
            p.edit().putString("recent", trimmed.toString()).apply();
        } catch (Exception ignored) { }
    }

    static synchronized void enqueue(Context ctx, JSONObject item) {
        try {
            SharedPreferences p = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray q = new JSONArray(p.getString("queue", "[]"));
            q.put(item);
            JSONArray trimmed = new JSONArray();
            for (int i = Math.max(0, q.length() - MAX_QUEUE); i < q.length(); i++) trimmed.put(q.get(i));
            p.edit().putString("queue", trimmed.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** Kirim ulang notifikasi yang tadi gagal terkirim (mis. saat sinyal putus). */
    static synchronized void flushQueue(Context ctx) {
        try {
            SharedPreferences p = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray q = new JSONArray(p.getString("queue", "[]"));
            if (q.length() == 0) return;
            JSONArray left = new JSONArray();
            for (int i = 0; i < q.length(); i++) {
                JSONObject it = q.getJSONObject(i);
                if (!send(ctx, it, false)) left.put(it);
            }
            p.edit().putString("queue", left.toString()).apply();
        } catch (Exception ignored) { }
    }

    static int queueSize(Context ctx) {
        try {
            return new JSONArray(ctx.getSharedPreferences(PREFS, MODE_PRIVATE).getString("queue", "[]")).length();
        } catch (Exception e) { return 0; }
    }

    static void ping(Context ctx) {
        JSONObject o = new JSONObject();
        try { o.put("act", "ping"); } catch (Exception ignored) { }
        send(ctx, o, false);
    }

    /**
     * POST ke api_notif.php. Mengembalikan true bila server menerima (HTTP 2xx
     * atau 4xx yang final); false bila perlu dicoba lagi (jaringan/5xx).
     */
    static boolean send(Context ctx, JSONObject item, boolean test) {
        return sendRaw(ctx, item, test) != null;
    }

    static String sendRaw(Context ctx, JSONObject item, boolean test) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        String url = p.getString("url", "");
        String token = p.getString("token", "");
        if (url.isEmpty() || token.isEmpty()) return null;
        HttpURLConnection c = null;
        try {
            StringBuilder body = new StringBuilder("token=").append(enc(token));
            java.util.Iterator<String> keys = item.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                body.append('&').append(enc(k)).append('=').append(enc(item.optString(k, "")));
            }
            if (test) body.append("&test=1");
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
            c.setRequestProperty("User-Agent", "MejaUtamaApp/1.0 PayNotif");
            try (OutputStream os = c.getOutputStream()) { os.write(data); }
            int code = c.getResponseCode();
            if (code >= 500) return null;
            java.io.InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) return "";
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[2048]; int n;
            while ((n = in.read(b)) > 0) buf.write(b, 0, n);
            return buf.toString("UTF-8");
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static String enc(String s) {
        try { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); } catch (Exception e) { return ""; }
    }
}
