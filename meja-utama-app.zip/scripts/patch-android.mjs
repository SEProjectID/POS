// Menempelkan kode native kustom ke proyek android/ hasil `cap add android`:
//  - ThermalPrinterPlugin (cetak Bluetooth ESC/POS) + MainActivity (layar tetap nyala, unduhan, suara)
//  - izin Bluetooth & pengaturan keyboard di AndroidManifest.xml
//  - versi + penandatanganan rilis di app/build.gradle
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'app.config.json'), 'utf8'));
const appId = cfg.appId;
const appName = cfg.appName;

const androidApp = path.join(root, 'android', 'app');
const javaDir = path.join(androidApp, 'src', 'main', 'java', ...appId.split('.'));
fs.mkdirSync(javaDir, { recursive: true });

// 1) Java
for (const f of fs.readdirSync(path.join(root, 'native', 'java'))) {
  const code = fs.readFileSync(path.join(root, 'native', 'java', f), 'utf8').replaceAll('__APP_ID__', appId);
  fs.writeFileSync(path.join(javaDir, f), code);
}

function edit(file, fn) {
  const p = path.join(androidApp, file);
  const before = fs.readFileSync(p, 'utf8');
  const after = fn(before);
  fs.writeFileSync(p, after);
}
function must(str, from, to) {
  if (str.includes(to.split('\n')[0]) && !str.includes(from)) return str; // sudah dipatch
  if (!str.includes(from)) throw new Error('Pola tidak ditemukan: ' + from.slice(0, 60));
  return str.replace(from, to);
}

// 2) AndroidManifest.xml
edit('src/main/AndroidManifest.xml', (s) => {
  if (s.includes('BLUETOOTH_CONNECT')) return s;
  s = must(s, 'android:allowBackup="true"', 'android:allowBackup="false"');
  s = must(s, 'android:launchMode="singleTask"', 'android:launchMode="singleTask"\n            android:windowSoftInputMode="adjustResize"');
  s = must(s, '<uses-permission android:name="android.permission.INTERNET" />',
`<uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <!-- Printer thermal Bluetooth -->
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-feature android:name="android.hardware.bluetooth" android:required="false" />`);
  return s;
});

// 3) app/build.gradle
edit('build.gradle', (s) => {
  if (s.includes('appVersionCode')) return s;
  s = must(s, "apply plugin: 'com.android.application'\n",
`apply plugin: 'com.android.application'

// Versi aplikasi: naikkan VERSION_CODE tiap rilis baru (diatur di GitHub Actions).
def appVersionCode = Integer.parseInt(System.getenv("VERSION_CODE") ?: "1")
def appVersionName = System.getenv("VERSION_NAME") ?: "1.0"
`);
  s = s.replace(/versionCode \d+\s*\n\s*versionName "[^"]*"/, 'versionCode appVersionCode\n        versionName appVersionName');
  if (!s.includes('versionCode appVersionCode')) throw new Error('versionCode tidak terpatch');
  s = must(s, '    buildTypes {\n        release {\n            minifyEnabled false',
`    signingConfigs {
        release {
            // Diisi otomatis oleh GitHub Actions bila secret keystore tersedia.
            def ks = System.getenv("KEYSTORE_FILE")
            if (ks) {
                storeFile file(ks)
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS")
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            if (System.getenv("KEYSTORE_FILE")) { signingConfig signingConfigs.release }
            minifyEnabled false`);
  return s;
});
// 4) Nama aplikasi (yang tampil di bawah ikon HP) — `cap add android` cuma
// menuliskannya SEKALI saat folder android/ pertama dibuat; kalau nanti
// appName di app.config.json diganti lagi, strings.xml (yang sudah lebih
// dulu ada di repo) tidak ikut berubah otomatis. Ditulis ulang di sini
// setiap kali setup dijalankan, supaya ganti nama aplikasi cukup edit
// app.config.json saja.
const stringsXmlPath = path.join(androidApp, 'src', 'main', 'res', 'values', 'strings.xml');
if (fs.existsSync(stringsXmlPath) && appName) {
  let xml = fs.readFileSync(stringsXmlPath, 'utf8');
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  xml = xml.replace(/<string name="app_name">.*?<\/string>/, `<string name="app_name">${esc(appName)}</string>`);
  xml = xml.replace(/<string name="title_activity_main">.*?<\/string>/, `<string name="title_activity_main">${esc(appName)}</string>`);
  fs.writeFileSync(stringsXmlPath, xml);
}

console.log('Patch Android selesai untuk', appId, '- nama aplikasi:', appName);
